#ifndef BATTLE_H
#define BATTLE_H

#include "character.h"

#include <stdlib.h>
#include <time.h>
#include <stdio.h>

// �v���g�^�C�v�錾
void battle(struct CharacterStats *character);

#endif // BATTLE_H