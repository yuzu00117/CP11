// character.h

#ifndef CHARACTER_H
#define CHARACTER_H

struct CharacterStats
{
    char CharacterName[100];
    int CharacterHP;
    int CharacterATK;
    int CharacterDEF;
};

#endif // CHARACTER_H
